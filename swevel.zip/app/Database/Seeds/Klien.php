<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Klien extends Seeder
{
    public function run()
    {
        //
    }
}
