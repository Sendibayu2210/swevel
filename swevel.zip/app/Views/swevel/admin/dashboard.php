<?= $this->extend('swevel/admin/admin-template'); ?>
<?= $this->section('content'); ?>

<div id="dashboard">
    <div class="container">
        <div class="mt-3 mb-5  h5">Dashboard</div>      
    </div>
</div>

<?= $this->endSection(); ?>